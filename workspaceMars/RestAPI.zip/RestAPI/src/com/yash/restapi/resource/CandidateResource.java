package com.yash.restapi.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.yash.restapi.model.Candidate;
import com.yash.restapi.service.CandidateService;

@Path("/candidates")
public class CandidateResource {
	CandidateService candidateService= new CandidateService(); 
	
	@GET
	@Path("/select")
	@Produces(MediaType.APPLICATION_XML)
	public List<Candidate> getAllCandidates(){
		return candidateService.getAllCandidates();
	}
	
	@GET
	@Path("/{candidate_id}")
	@Produces(MediaType.APPLICATION_XML)
	public Candidate getCandidate(@PathParam("candidate_Id") int candidate_id){
		return candidateService.getCandidate(candidate_id);
	}
}
