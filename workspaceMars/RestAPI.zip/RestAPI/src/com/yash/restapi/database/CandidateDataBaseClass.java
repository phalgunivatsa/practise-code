package com.yash.restapi.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.restapi.model.Candidate;
import com.yash.restapi.util.ConnectionProvider;

public class CandidateDataBaseClass {
	Candidate candidate = new Candidate();

	public Candidate getCandidate(int candidate_id) {

		return null;
	}

	public List<Candidate> getAllCandidates() {
		String query = "Select * from candidate, marks";
		Connection connection = ConnectionProvider.getConnection();
		PreparedStatement preparedstatement;
		ArrayList<Candidate> arrayList = new ArrayList<>();
		try {
			preparedstatement = connection.prepareStatement(query);
			preparedstatement.execute();
			ResultSet resultSet = preparedstatement.getResultSet();
			while (resultSet.next()) {
				Candidate candidate = new Candidate();
				int id = resultSet.getInt("candidate_id");
				String name = resultSet.getString("name");
				String city = resultSet.getString("city");
				candidate.setCandidate_id(id);
				candidate.setName(name);
				candidate.setCity(city);
				arrayList.add(candidate);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return null;

	}

}