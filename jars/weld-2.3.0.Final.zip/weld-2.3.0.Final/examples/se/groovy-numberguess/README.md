Weld SE Groovy Numberguess example
==================================

To run this example using Maven directly:

- Ensure that Maven 3 is installed and in your `PATH`
- Ensure that the `JAVA_HOME` environment variable is pointing to your JDK installation
- Open a command line or terminal window in the `examples/se/groovy-numberguess` directory
- Execute the following command

        mvn -Drun
